import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function HomePage() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Cek Saldo</Text>
      <Text style={styles.text}>Mutasi</Text>
      <Text style={styles.text}>Transfer</Text>
      <Text style={styles.text}>Transfer Antar Bank</Text>
      <Text style={styles.text}>Virtual Account</Text>
      <Text style={styles.text}>Cek Tagihan</Text>
      <Text style={styles.text}>Pembayaran Tagihan</Text>
      <Text style={styles.text}>Cek Kurs</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#004AAD',
  },
});