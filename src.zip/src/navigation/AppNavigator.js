import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import HomePage from '../screens/HomePage';
import SearchPage from '../screens/SearchPage';
import SideBarContent from '../components/SideBarContent';

const Drawer = createDrawerNavigator();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Drawer.Navigator drawerContent={(props) => <SideBarContent {...props} />}>
        <Drawer.Screen name="Home" component={HomePage} />
        <Drawer.Screen name="Search" component={SearchPage} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}